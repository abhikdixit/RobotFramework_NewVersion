class PrintJob(object):

    
    def __init__(self, jobtype, properties):
        self.jobtype = jobtype
        self.properties = properties